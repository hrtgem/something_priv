const Initialize = require('./src/Utils/Functions/Initialize');

(async () => {
  await Initialize();
})();