class Event {
    constructor(name) {
      this.name = name;
    };
  };
  
  module.exports = Event;