async function Sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
};

module.exports = Sleep;